﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using SistemaAPI.Interface;
using SistemaAPI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SistemaAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PessoaController : ControllerBase
    {
        //construtor.

        private readonly IPessoaRepositorio _pessoaRepositorio;

        public PessoaController(IPessoaRepositorio pessoaRepositorio)
        {
            _pessoaRepositorio = pessoaRepositorio;
        }

        [HttpGet("BuscarTodasPessoas")]
        public async Task<ActionResult<List<Pessoa>>> BuscarTodasPessoas()
        {
            List<Pessoa> pessoa = await _pessoaRepositorio.BuscarTodos();

            return Ok(pessoa);
        }

        [HttpPost("Create")]
        public async Task<ActionResult<List<Pessoa>>> Create(Pessoa model)
        {
            try
            {
                var novo = await _pessoaRepositorio.Adicionar(model);
                return Ok(novo);
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        [HttpPut("Edit")]
        public async Task<ActionResult<List<Pessoa>>> Edit(Pessoa model)
        {
            try
            {
                var editado = await _pessoaRepositorio.Salvar(model);
                return Ok(editado);                
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        [HttpDelete("Delete")]
        public async Task<ActionResult<List<Pessoa>>> Delete(Pessoa model)
        {
            try
            {
                var deletado = await _pessoaRepositorio.Apagar(model.Id);
                return Ok(deletado);
            }
            catch(Exception ex)
            {
                return null;
            }           
        }
    }
}
