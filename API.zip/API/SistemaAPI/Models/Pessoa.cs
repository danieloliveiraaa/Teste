﻿using System;

namespace SistemaAPI.Models
{
    public class Pessoa
    {
        public int Id { get; set; }       
        public string NomeCompleto { get; set; }
        public DateTime DataNascimento { get; set; }
        public string RendaValor { get; set; }
        public string CPF { get; set; }
    }
}
