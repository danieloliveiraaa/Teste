﻿using SistemaAPI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SistemaAPI.Interface
{
    public interface IPessoaRepositorio
    {
        Task<List<Pessoa>> BuscarTodos();
        Task<Pessoa> Adicionar(Pessoa model);
        Task<Pessoa> BuscarPorId(int id);
        Task<Pessoa> Salvar(Pessoa modelUpdate);
        Task<bool> Apagar(int id);
    }
}
