﻿using Microsoft.EntityFrameworkCore;
using Sistema.Data;
using SistemaAPI.Interface;
using SistemaAPI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SistemaAPI.Repositorio
{
    public class PessoaRepositorio : IPessoaRepositorio
    {
        private readonly BDContext _context;

        public PessoaRepositorio(BDContext context)
        {
            _context = context;
        }

        public async Task<Pessoa> Adicionar(Pessoa model)
        {
            await _context.Pessoa.AddAsync(model);
            await _context.SaveChangesAsync();

            return model;
        }

        public async Task<Pessoa> BuscarPorId(int id)
        {
            return await _context.Pessoa.FirstOrDefaultAsync(x => x.Id == id);
        }

        public async Task<List<Pessoa>> BuscarTodos()
        {            
            return await _context.Pessoa.ToListAsync();
        }

        public async Task<Pessoa> Salvar(Pessoa model)
        {
            try
            {
                Pessoa pessoa = await BuscarPorId(model.Id);

                if (pessoa == null)
                    throw new Exception("Não encontrado.");

                pessoa.NomeCompleto = model.NomeCompleto;
                pessoa.DataNascimento = model.DataNascimento;
                pessoa.RendaValor = model.RendaValor;
                pessoa.CPF = model.CPF;

                _context.Pessoa.Update(pessoa);
                await _context.SaveChangesAsync();

                return pessoa;
            }
            catch(Exception ex)
            {
                return null;
            }
        }

        public async Task<bool> Apagar(int id)
        {
            try
            {
                Pessoa pessoa = await BuscarPorId(id);

                if (pessoa == null)
                    throw new Exception("Erro ao deletar, pessoa não encontrada.");
                else
                {
                    _context.Pessoa.Remove(pessoa);
                    await _context.SaveChangesAsync();
                }

                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }
    }
}
